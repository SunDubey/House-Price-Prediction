# Real-Estate-valuation-analysis-
Applying Performance metrics on Regression problem : Real estate valuation as per European standards and AVM.
